# V7 ZIM-Import Modul

## Übersicht

Dieses Modul ermöglicht den Import von ZIM-Förderanträgen in die V7-Datenbank.

## Dateien

| Datei | Beschreibung | Zielort im Projekt |
|-------|--------------|-------------------|
| `zim-pdf-parser.py` | Python-Skript zum Parsen von ZIM-PDFs | `scripts/` |
| `zim-pdf-types.ts` | TypeScript-Typen für ZIM-Daten | `src/lib/parsers/` |
| `import-page.tsx` | V7 Import-Seite mit Tabs | `src/app/v7/import/page.tsx` |
| `beispiel-output.json` | Beispiel JSON-Ausgabe | (nur Referenz) |

## Installation

### 1. Dateien kopieren

```bash
# Im Projekt-Root
cp zim-pdf-parser.py scripts/
cp zim-pdf-types.ts src/lib/parsers/
cp import-page.tsx src/app/v7/import/page.tsx
```

### 2. Python-Abhängigkeiten

```bash
pip install pypdf
```

## Verwendung

### Python-Parser (lokal)

```bash
# Zusammenfassung anzeigen
python scripts/zim-pdf-parser.py pfad/zur/antrag.pdf

# JSON exportieren
python scripts/zim-pdf-parser.py pfad/zur/antrag.pdf -o json

# JSON in Datei speichern
python scripts/zim-pdf-parser.py pfad/zur/antrag.pdf -o json -s output.json
```

### Web-Import

1. PDF lokal mit Python-Parser zu JSON konvertieren
2. In V7-App unter `/v7/import` → Tab "ZIM-Projektantrag"
3. JSON-Datei hochladen
4. Vorschau prüfen
5. "In Datenbank importieren" klicken

## Extrahierte Daten

### Projekt
- Name, Kurzname, FKZ
- Laufzeit (Start/Ende)
- Förderquote, Gesamtkosten, Zuwendung
- Gesamt-PM, Gesamt-PK

### Antragsteller
- Firma, Rechtsform
- Adresse (Straße, PLZ, Ort, Bundesland)
- Website
- Ansprechpartner (Name, Funktion, Telefon, E-Mail)

### Mitarbeiter (pro MA)
- Name, Qualifikation, Qualifikationsgruppe (1-4)
- Geburtsdatum, Funktion, Angestellt seit
- Jahresbrutto, Stundensatz
- Wochenstunden, Teilzeitfaktor
- PM gesamt, Kosten gesamt
- PM pro Jahr

### Arbeitspakete
- AP-Nummer, Beschreibung
- Zeitraum (von - bis)
- MA-Zuordnung, PM

## Datenbank-Mapping

| ZIM-Feld | V7-Tabelle | V7-Spalte |
|----------|------------|-----------|
| Antragsteller | `v7_client_companies` | name, legal_form, ... |
| Projekt | `v7_projects` | name, short_name, funding_reference, ... |
| Mitarbeiter | `v7_employees` | first_name, last_name, qualification, ... |
| MA-Projekt | `v7_project_employees` | planned_person_months, planned_costs |

## Hinweise

- ZIM-PDFs verwenden Adobe XFA-Format (LiveCycle)
- Browser können XFA nicht parsen → Python-Skript nötig
- Für BMBF/KMU-Innovativ: Manuell anlegen (kein PDF-Import)
